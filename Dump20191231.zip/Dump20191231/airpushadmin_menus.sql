-- MySQL dump 10.13  Distrib 8.0.17, for macos10.14 (x86_64)
--
-- Host: localhost    Database: airpushadmin
-- ------------------------------------------------------
-- Server version	5.6.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `menus`
--

DROP TABLE IF EXISTS `menus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `menus` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `href` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_id` int(10) unsigned DEFAULT NULL,
  `menu_id` int(10) unsigned NOT NULL,
  `sequence` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menus`
--

LOCK TABLES `menus` WRITE;
/*!40000 ALTER TABLE `menus` DISABLE KEYS */;
INSERT INTO `menus` VALUES (1,'Dashboard','/','cil-speedometer','link',NULL,1,1),(2,'Login','/login','cil-account-logout','link',NULL,1,2),(3,'Register','/register','cil-account-logout','link',NULL,1,3),(4,'Theme',NULL,NULL,'title',NULL,1,4),(5,'Colors','/colors','cil-drop1','link',NULL,1,5),(6,'Typography','/typography','cil-pencil','link',NULL,1,6),(7,'Base',NULL,'cil-puzzle','dropdown',NULL,1,7),(8,'Breadcrumb','/base/breadcrumb',NULL,'link',7,1,8),(9,'Cards','/base/cards',NULL,'link',7,1,9),(10,'Carousel','/base/carousel',NULL,'link',7,1,10),(11,'Collapse','/base/collapse',NULL,'link',7,1,11),(12,'Forms','/base/forms',NULL,'link',7,1,12),(13,'Jumbotron','/base/jumbotron',NULL,'link',7,1,13),(14,'List group','/base/list-group',NULL,'link',7,1,14),(15,'Navs','/base/navs',NULL,'link',7,1,15),(16,'Pagination','/base/pagination',NULL,'link',7,1,16),(17,'Popovers','/base/popovers',NULL,'link',7,1,17),(18,'Progress','/base/progress',NULL,'link',7,1,18),(19,'Scrollspy','/base/scrollspy',NULL,'link',7,1,19),(20,'Switches','/base/switches',NULL,'link',7,1,20),(21,'Tables','/base/tables',NULL,'link',7,1,21),(22,'Tabs','/base/tabs',NULL,'link',7,1,22),(23,'Tooltips','/base/tooltips',NULL,'link',7,1,23),(24,'Buttons',NULL,'cil-cursor','dropdown',NULL,1,24),(25,'Buttons','/buttons/buttons',NULL,'link',24,1,25),(26,'Buttons Group','/buttons/button-group',NULL,'link',24,1,26),(27,'Dropdowns','/buttons/dropdowns',NULL,'link',24,1,27),(28,'Brand Buttons','/buttons/brand-buttons',NULL,'link',24,1,28),(29,'Charts','/charts','cil-chart-pie','link',NULL,1,29),(30,'Icons',NULL,'cil-star','dropdown',NULL,1,30),(31,'CoreUI Icons','/icon/coreui-icons',NULL,'link',30,1,31),(32,'Flags','/icon/flags',NULL,'link',30,1,32),(33,'Brands','/icon/brands',NULL,'link',30,1,33),(34,'Notifications',NULL,'cil-bell','dropdown',NULL,1,34),(35,'Alerts','/notifications/alerts',NULL,'link',34,1,35),(36,'Badge','/notifications/badge',NULL,'link',34,1,36),(37,'Modals','/notifications/modals',NULL,'link',34,1,37),(38,'Widgets','/widgets','cil-calculator','link',NULL,1,38),(39,'Extras',NULL,NULL,'title',NULL,1,39),(40,'Pages',NULL,'cil-star','dropdown',NULL,1,40),(41,'Login','/login',NULL,'link',40,1,41),(42,'Register','/register',NULL,'link',40,1,42),(43,'Error 404','/404',NULL,'link',40,1,43),(44,'Error 500','/500',NULL,'link',40,1,44),(45,'Download CoreUI','https://coreui.io','cil-cloud-download','link',NULL,1,45),(46,'Try CoreUI PRO','https://coreui.io/pro/','cil-layers','link',NULL,1,46),(47,'Dashboard','/',NULL,'link',NULL,2,47),(48,'Campaigns','/campaigns',NULL,'link',NULL,2,48),(49,'Users','/users',NULL,'link',NULL,2,49),(50,'Settings',NULL,'','dropdown',NULL,2,50),(51,'Edit menu','/menu/menu',NULL,'link',50,2,51),(52,'Edit menu elements','/menu/element',NULL,'link',50,2,52),(53,'Edit roles','/roles',NULL,'link',50,2,53);
/*!40000 ALTER TABLE `menus` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-12-31  0:05:56
