-- MySQL dump 10.13  Distrib 8.0.17, for macos10.14 (x86_64)
--
-- Host: localhost    Database: airpushadmin
-- ------------------------------------------------------
-- Server version	5.6.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `campaigns`
--

DROP TABLE IF EXISTS `campaigns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `campaigns` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `start` datetime NOT NULL,
  `end` datetime NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `geo_targeting` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `day_parting` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `devices` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ad_format_id` bigint(20) unsigned NOT NULL,
  `traffic_source` enum('applications','mobile websites') COLLATE utf8mb4_unicode_ci NOT NULL,
  `status_id` bigint(20) unsigned NOT NULL,
  `category_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `daily_budget` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `impressions` int(11) DEFAULT NULL,
  `clicks` int(11) DEFAULT NULL,
  `ctr` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `current_bid` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cpc_bid` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `average_bid` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `spend` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `conversion` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `conversion_rate` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `campaigns_category_id_foreign` (`category_id`),
  KEY `campaigns_status_id_foreign` (`status_id`),
  KEY `campaigns_ad_format_id_foreign` (`ad_format_id`),
  KEY `campaigns_user_id_foreign` (`user_id`),
  CONSTRAINT `campaigns_ad_format_id_foreign` FOREIGN KEY (`ad_format_id`) REFERENCES `ad_formats` (`id`),
  CONSTRAINT `campaigns_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`),
  CONSTRAINT `campaigns_status_id_foreign` FOREIGN KEY (`status_id`) REFERENCES `statuses` (`id`),
  CONSTRAINT `campaigns_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `campaigns`
--

LOCK TABLES `campaigns` WRITE;
/*!40000 ALTER TABLE `campaigns` DISABLE KEYS */;
INSERT INTO `campaigns` VALUES (2,'2019-12-29 13:24:12','2019-12-29 13:24:12','2019-12-29 15:24:12','2019-12-29 15:24:12','December','all','all','all',1,'applications',1,1,1,'100',0,0,'0.6',NULL,NULL,NULL,NULL,NULL,'1'),(3,'2019-12-29 13:30:04','2019-12-29 13:30:04','2019-12-29 15:30:04','2019-12-29 15:30:04','Christmas','all','all','all',1,'applications',1,1,1,'100',0,0,'0.6',NULL,NULL,NULL,NULL,NULL,'1'),(4,'2019-12-29 13:30:12','2019-12-29 13:30:12','2019-12-29 15:30:12','2019-12-29 15:30:12','January','all','all','all',1,'applications',1,1,1,'100',0,0,'0.6',NULL,NULL,NULL,NULL,NULL,'1'),(5,'2019-12-29 13:30:20','2019-12-29 13:30:20','2019-12-29 15:30:20','2019-12-29 15:30:20','February','all','all','all',1,'applications',1,1,1,'100',0,0,'0.6',NULL,NULL,NULL,NULL,NULL,'1'),(6,'2019-12-29 13:30:56','2019-12-29 13:30:56','2019-12-29 15:30:56','2019-12-29 15:30:56','February 1','all','all','all',1,'applications',1,1,2,'0',0,0,'0.6',NULL,NULL,NULL,NULL,NULL,'1'),(7,'2019-12-29 14:40:35','2019-12-29 14:40:35','1971-01-28 00:00:00','1991-07-21 00:00:00','Moses Ford','all','morning','ios',1,'mobile websites',5,2,1,'49',NULL,NULL,NULL,'36',NULL,NULL,NULL,NULL,NULL),(8,'2019-12-29 15:56:54','2019-12-29 15:56:54','2002-05-04 00:00:00','2015-01-20 00:00:00','Tatum Wynn','Limpopo','day','android',3,'mobile websites',5,11,1,'37',NULL,NULL,NULL,'4',NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `campaigns` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-12-31  0:05:53
