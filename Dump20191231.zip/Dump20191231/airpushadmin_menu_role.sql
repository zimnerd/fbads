-- MySQL dump 10.13  Distrib 8.0.17, for macos10.14 (x86_64)
--
-- Host: localhost    Database: airpushadmin
-- ------------------------------------------------------
-- Server version	5.6.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `menu_role`
--

DROP TABLE IF EXISTS `menu_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `menu_role` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `role_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `menus_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=106 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu_role`
--

LOCK TABLES `menu_role` WRITE;
/*!40000 ALTER TABLE `menu_role` DISABLE KEYS */;
INSERT INTO `menu_role` VALUES (1,'guest',1),(2,'user',1),(3,'admin',1),(4,'guest',2),(5,'guest',3),(6,'user',4),(7,'admin',4),(8,'user',5),(9,'admin',5),(10,'user',6),(11,'admin',6),(12,'user',7),(13,'admin',7),(14,'user',8),(15,'admin',8),(16,'user',9),(17,'admin',9),(18,'user',10),(19,'admin',10),(20,'user',11),(21,'admin',11),(22,'user',12),(23,'admin',12),(24,'user',13),(25,'admin',13),(26,'user',14),(27,'admin',14),(28,'user',15),(29,'admin',15),(30,'user',16),(31,'admin',16),(32,'user',17),(33,'admin',17),(34,'user',18),(35,'admin',18),(36,'user',19),(37,'admin',19),(38,'user',20),(39,'admin',20),(40,'user',21),(41,'admin',21),(42,'user',22),(43,'admin',22),(44,'user',23),(45,'admin',23),(46,'user',24),(47,'admin',24),(48,'user',25),(49,'admin',25),(50,'user',26),(51,'admin',26),(52,'user',27),(53,'admin',27),(54,'user',28),(55,'admin',28),(56,'user',29),(57,'admin',29),(58,'user',30),(59,'admin',30),(60,'user',31),(61,'admin',31),(62,'user',32),(63,'admin',32),(64,'user',33),(65,'admin',33),(66,'user',34),(67,'admin',34),(68,'user',35),(69,'admin',35),(70,'user',36),(71,'admin',36),(72,'user',37),(73,'admin',37),(74,'user',38),(75,'admin',38),(76,'user',39),(77,'admin',39),(78,'user',40),(79,'admin',40),(80,'user',41),(81,'admin',41),(82,'user',42),(83,'admin',42),(84,'user',43),(85,'admin',43),(86,'user',44),(87,'admin',44),(88,'guest',45),(89,'user',45),(90,'admin',45),(91,'guest',46),(92,'user',46),(93,'admin',46),(94,'guest',47),(95,'user',47),(96,'admin',47),(99,'admin',49),(100,'admin',50),(101,'admin',51),(102,'admin',52),(103,'admin',53),(104,'admin',48),(105,'user',48);
/*!40000 ALTER TABLE `menu_role` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-12-31  0:05:55
